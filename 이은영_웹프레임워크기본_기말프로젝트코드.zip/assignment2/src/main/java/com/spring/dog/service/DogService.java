package com.spring.dog.service;

import com.spring.dog.impl.DogDO;

public interface DogService {
	void insertDogInfo(DogDO ddo);
}
